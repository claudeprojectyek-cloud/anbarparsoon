// استخراج داده اولیه (۱۱۳ قلم) از schema.sql
const fs = require('fs');
const sql = fs.readFileSync(process.argv[2], 'utf8');
const start = sql.indexOf('INSERT INTO items');
const end = sql.indexOf(';', start);
const body = sql.slice(sql.indexOf('VALUES', start) + 6, end);
const rows = [];
let i = 0;
function readVal() {
  while (/\s|,/.test(body[i])) i++;
  if (body.startsWith('NULL', i)) { i += 4; return null; }
  if (body[i] === "'") {
    i++; let s = '';
    while (i < body.length) {
      if (body[i] === "'" && body[i + 1] === "'") { s += "'"; i += 2; continue; }
      if (body[i] === '\\') { s += body[i + 1]; i += 2; continue; }
      if (body[i] === "'") { i++; break; }
      s += body[i++];
    }
    return s;
  }
  let n = ''; while (/[0-9.\-]/.test(body[i])) n += body[i++];
  return Number(n);
}
while (i < body.length) {
  while (i < body.length && body[i] !== '(') i++;
  if (i >= body.length) break;
  i++;
  const v = [];
  for (let k = 0; k < 6; k++) v.push(readVal());
  while (body[i] !== ')') i++;
  i++;
  rows.push({ category: v[0], name: v[1], brand: v[2], quantity: v[3], unit: v[4], notes: v[5] });
}
console.log(rows.length, new Set(rows.map(r => r.category)).size);
fs.writeFileSync(process.argv[3], '/* داده اولیه انبار — ۱۱۳ قلم (برگرفته از schema.sql) */\nwindow.ANBAR_SEED = ' + JSON.stringify(rows) + ';\n');
