// تولید پوشه‌ی www (نسخه‌ی آفلاین) از سورس اصلی PHP — اجرا: node scripts/build-www.js <مسیر anbar-parsoon>
const fs = require('fs'), path = require('path');
const SRC = process.argv[2], OUT = path.join(__dirname, '..', 'www');
const cp = (a, b) => { fs.mkdirSync(path.dirname(b), { recursive: true }); fs.cpSync(a, b, { recursive: true }); };
const rd = f => fs.readFileSync(path.join(SRC, f), 'utf8');
const wr = (f, s) => { fs.mkdirSync(path.dirname(path.join(OUT, f)), { recursive: true }); fs.writeFileSync(path.join(OUT, f), s); };

// دارایی‌های ثابت
cp(path.join(SRC, 'assets/css'), path.join(OUT, 'assets/css'));
cp(path.join(SRC, 'assets/fonts'), path.join(OUT, 'assets/fonts'));
cp(path.join(SRC, 'assets/icons'), path.join(OUT, 'assets/icons'));
cp(path.join(SRC, 'assets/js/vendor'), path.join(OUT, 'assets/js/vendor'));
const nm = path.join(__dirname, '..', 'node_modules');
cp(path.join(nm, 'docx/dist/index.iife.js'), path.join(OUT, 'assets/js/vendor/docx.iife.js'));
cp(path.join(nm, 'bcryptjs/dist/bcrypt.min.js'), path.join(OUT, 'assets/js/vendor/bcrypt.min.js'));

const stripPhpHeader = s => s.slice(s.indexOf('?>') + 2).replace(/^\n/, '');
const GUARD = "<script>try{if(localStorage.getItem('anbar_auth_ok')!=='1')location.replace('login.html');}catch(e){}</script>";
const CORE = ['assets/js/vendor/bcrypt.min.js', 'assets/js/offline/seed-data.js', 'assets/js/offline/offline-api.js']
    .map(s => `<script src="${s}"></script>`).join('\n');

// ---- index.html
let idx = stripPhpHeader(rd('index.php'));
idx = idx.replace(/<\?php echo htmlspecialchars\(APP_VERSION[^?]*\?>/, '3.0.0 — آفلاین');
idx = idx.replace('<meta charset="UTF-8">', '<meta charset="UTF-8">\n' + GUARD);
idx = idx.replace(/<link rel="manifest"[^>]*>\n?/, '');
idx = idx.replace(/<script src="assets\/js\/bundle\.min\.js[^>]*><\/script>\s*<script>[\s\S]*?<\/script>/,
    CORE + '\n<script src="assets/js/bundle.min.js?v=3.0.0"></script>\n<script src="assets/js/offline/native-extras.js"></script>');
idx = idx.replace('با اسکن این کد، صفحه‌ی فقط‌خواندنی همین دسته‌بندی باز می‌شود.', 'این کد، نام دسته‌بندی را نشان می‌دهد و برای چسباندن روی قفسه/کارتن چاپ می‌شود.');
if (/<\?php|\.php/.test(idx.replace(/api\/[a-z-]+\.php/g, ''))) console.warn('هشدار: هنوز اثری از PHP در index.html مانده');
wr('index.html', idx);

// ---- login.html
let lg = stripPhpHeader(rd('login.php'));
lg = lg.replace(/var REDIRECT_TARGET = <\?php[\s\S]*?\?>;/, "var REDIRECT_TARGET = 'index.html';\n    try { if (localStorage.getItem('anbar_auth_ok') === '1') { location.replace('index.html'); } } catch (e) {}");
lg = lg.replace(/<link rel="manifest"[^>]*>\n?/, '');
lg = lg.replace('<script>\n(function () {', CORE + '\n<script>\n(function () {');
wr('login.html', lg);

// ---- category.html (صفحه‌ی فقط‌خواندنی؛ حالا با جاوااسکریپت از دیتابیس داخلی پر می‌شود)
wr('category.html', `<!DOCTYPE html>
<html lang="fa" dir="rtl">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
${GUARD}
<title>دسته‌بندی | انبار پرسون بام بین‌الملل</title>
<link rel="stylesheet" href="assets/css/vazirmatn-font-face.css?v=3.0.0">
<meta name="theme-color" content="#16324f">
<link rel="stylesheet" href="assets/css/style.min.css?v=3.0.0">
</head>
<body>
<script>document.documentElement.setAttribute('data-theme', (function(){try{return localStorage.getItem('anbar-parsoon-theme')||'light'}catch(e){return 'light'}})());</script>
<div class="category-page">
  <header class="category-page-header">
    <div class="brand"><div class="brand-mark">پب</div><div><div class="brand-name">پرسون بام بین‌الملل</div><div class="brand-sub">نمای فقط‌خواندنی دسته‌بندی</div></div></div>
    <a class="btn btn-ghost btn-sm" href="index.html">بازگشت به سامانه</a>
  </header>
  <div id="catRoot"></div>
  <footer class="category-page-footer">این صفحه فقط‌خواندنی است.</footer>
</div>
${CORE}
<script>
(function () {
  function h(v){return String(v==null?'':v).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');}
  function n(v){v=Number(v)||0;return (Number.isInteger(v)?v:Math.round(v*100)/100).toLocaleString('fa-IR');}
  var name=(new URLSearchParams(location.search).get('name')||'').trim(), root=document.getElementById('catRoot');
  if(!name){root.innerHTML='<div class="state-block"><div class="state-title">دسته‌بندی مشخص نشده است.</div></div>';return;}
  document.title=name+' | دسته‌بندی | انبار پرسون بام بین‌الملل';
  fetch('api/items.php?category='+encodeURIComponent(name)+'&sort=name&dir=asc').then(r=>r.json()).then(function(j){
    var items=(j&&j.data)||[];
    if(!items.length){root.innerHTML='<h1 class="category-page-title">'+h(name)+'</h1><div class="state-block"><div class="state-title">این دسته‌بندی خالی است یا وجود ندارد.</div></div>';return;}
    var total=items.reduce(function(s,i){return s+Number(i.quantity)},0);
    root.innerHTML='<h1 class="category-page-title">'+h(name)+'</h1>'+
     '<div class="category-page-stats"><div class="stat-card"><div class="stat-label">تعداد اقلام</div><div class="stat-value">'+n(items.length)+'</div></div>'+
     '<div class="stat-card"><div class="stat-label">جمع کل موجودی</div><div class="stat-value">'+n(total)+'</div></div></div>'+
     '<div class="table-wrap"><table class="items-table"><thead><tr><th>نام کالا</th><th>برند / مشخصات</th><th>تعداد</th><th>واحد</th></tr></thead><tbody>'+
     items.map(function(i){return '<tr><td>'+h(i.name)+'</td><td class="muted">'+(i.brand?h(i.brand):'—')+'</td><td class="qty-cell">'+n(i.quantity)+'</td><td>'+h(i.unit)+'</td></tr>';}).join('')+
     '</tbody></table></div><div class="items-cards category-page-cards">'+
     items.map(function(i){return '<div class="item-card"><div class="item-card-top"><div><div class="item-card-title">'+h(i.name)+'</div>'+(i.brand?'<div class="item-card-brand">'+h(i.brand)+'</div>':'')+'</div></div><div class="item-card-row"><span class="muted">تعداد</span><span>'+n(i.quantity)+' '+h(i.unit)+'</span></div></div>';}).join('')+'</div>';
  });
})();
</script>
</body>
</html>
`);

// ---- bundle.min.js
let b = rd('assets/js/bundle.min.js');
const rep = (from, to, all) => { if (!b.includes(from)) throw new Error('الگو پیدا نشد: ' + from); b = all ? b.split(from).join(to) : b.replace(from, to); };
rep('login.php', 'login.html', true);                         // هدایت به صفحه‌ی ورود
rep('scheduleRebuild:s', 'scheduleRebuild:function(){}');     // ساخت کش پس‌زمینه‌ی PDF/Excel روی گوشی لازم نیست (سنگین است)
rep('const e=new URL("category.php",window.location.href);return e.searchParams.set("name",t),e.toString()',
    'return "انبار پرسون بام بین‌الملل\\nدسته‌بندی: "+t');
fs.writeFileSync(path.join(OUT, 'assets/js/bundle.min.js'), b);
console.log('OK');
