package ir.parsoonbam.anbar;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
